package com.example.task

data class user(val id: Int,val  firstname: String , val phone: Int)
